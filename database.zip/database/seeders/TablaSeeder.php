<?php

namespace Database\Seeders;

use App\Models\backend\Tabla;
use Illuminate\Database\Seeder;

class TablaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $tabla[1]=array('Doctor', 'Empresario', 'Dibujante', 'Arquitecto',
        'Analista', 'Programador', 'Enfermera', '', '', '');
        // crea profesiones
        for($i = 0; $i < \sizeof($tabla[1]); $i++){
            Tabla::factory(1)->create([
                'tabla'=>5000,
                'tabla_id' => $i,
                'nombre' => $tabla[1][$i],
                'descripcion' => $i==0 ?? 'Profesiones',
            ]
        );

        }

    }
}
